<?php

ini_set('max_execution_time','10000');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';
        

    function send_mail($to, $subject, $message)
    {

        $mail = new PHPMailer(true);
        
        try {
            // $mail->SMTPDebug = 2;                               // Enable verbose debug output
            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';                       // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'ananthajothi0806@gmail.com';      // SMTP username
            $mail->Password = 'nbbp fprz hmju itev';                       // SMTP password
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587;                                    // TCP port to connect to
                                                                  // Set email format to HTML
            // if($attachments != false)
            // {
            //     $mail->addAttachment($attachments, $attachment_name ,$encoding = 'base64');
            // }

            $html = '<div style="width: 100%;display: block">
            <div>
                <div style="text-align: center;width: 100%;padding: 8px;">
                    <img src="https://i.imgur.com/ZDGCzDF.jpeg" width="72" height="72" style="float: left;">
                    <h2> <span style="color: #d41378;" >J</span><span style="color:#262626" >o</span> <span style="color: #d41378;">A</span> <span style="color:#262626"> dmin</span></h2>
                </div>
                <hr style=" width: 100%;background-color: #d41378;height: 4px;border-radius: 8px;"/>
                <div style="margin-top: 5px;text-align: center;">
                    <img style="width: 100%" src="https://admin.sbkc.in/assets/images/mail.png">
                </div>
                <div style="width: 100%;text-align: center;color: #d41378;">
                    <h3>'.$subject.'</h3>
                </div>
                <div style="width: 100%;text-align: center;margin-top:-12px;color: #262626;">
                    <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                    '. $message .'
                    </p>
                </div>
                <hr style=" width: 100%;background-color: #d41378;height: 4px;border-radius: 8px;"/>
                <div style="width: 100%;text-align: center;">
                    For more details visit <a href="https://new.sbkc.in/" style="text-decoration: none;color: #d41378;font-weight: bold;" target="_blank">Jo</a>
                </div> 
            </div>
        </div>';
            
            
            $mail->Subject = $subject;
            $mail->isHTML(true);   
            $mail->Body = $html;
            
            
            if(is_array($to))
            {   
                $to = array_unique($to);
                
                $to = array_values($to);

                for ($i=0; $i<count($to); $i++) 
                { 
    
                    $mail->setFrom("ananthajothi0806@gmail.com","jo Admin");
                    $mail->addAddress($to[$i]);
                    
                }
            }
            else
            {
                
                $mail->setFrom("ananthajothi0806@gmail.com","jo Admin");
                $mail->addAddress($to);
                
            }
            // $mail->send()

           

            if($mail->send())
            {//
                // $result = array(
                //     'error' => 0,
                //     'msg' => 'Mail sent successfully !!'
                // );
                // echo json_encode($result);
                return true;
            }
            else
            {
                // $result = array(
                //     'error' => 2,
                //     'msg' => 'Failed to send the message !!'
                // );
                // echo json_encode($result);
                return false;
            }
        } catch (Exception $e) {
    
            // $result = array(
            //     'error' => $e,
            //     'msg' => 'Failed to send the message !!'
            // );
            // echo json_encode($result);
            // exit();
            return false;
        }
    }
        

?>
